function sayHello()
{
//TODO:return the string “Hello World“
document.write ("Hello World!");
}
