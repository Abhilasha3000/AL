package com.capgemini.jdbc;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;




public class JdbcCRUD {
	
	DBUtil dbutil=new DBUtil();
	
	public void save(Fruits fruits) {
		
		
		try(Connection con=dbutil.getConnection())
		{
			Statement stmt=con.createStatement();
			PreparedStatement pstmt=con.prepareStatement("Insert into Fruits values(?,?)");
			pstmt.setString(1, fruits.getName());
			pstmt.setInt(2, fruits.getQuantity());			
			pstmt.execute();			
			
		} catch (SQLException e) {
			
			System.out.println("Sql exception "+e);			
		}		
	}
	
	public List<Fruits> display() {		
		
		List<Fruits> list =new ArrayList<>();
	
		try(Connection con=dbutil.getConnection())
		{
			PreparedStatement pstmt=con.prepareStatement("select * from Fruits");			
			ResultSet rs=pstmt.executeQuery();
			if(rs.next()==false)
			{
				System.out.println("Empty table");				
			}
			while(rs.next())
			{
				list.add(new Fruits(rs.getString(1),rs.getInt(2)));
			}
				
		}
		catch(SQLException e)
		{
			System.out.println("Sql exception "+e);	
		}
		return list;
	}

	public void delete(String name) {
		
		try(Connection con=dbutil.getConnection())
		{
			PreparedStatement pstmt=con.prepareStatement("Delete from Fruits where name=?");
			pstmt.setString(1, name);			
			if(pstmt.execute())
			{
				System.out.println("Deleted");
			}
		}			
		catch(SQLException e)
		{
			System.out.println("Sql exception "+e);	
		}
		
	}

	
}
