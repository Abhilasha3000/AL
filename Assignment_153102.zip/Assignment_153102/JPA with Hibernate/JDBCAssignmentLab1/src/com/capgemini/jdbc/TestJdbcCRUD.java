package com.capgemini.jdbc;

import java.util.List;
import java.util.Scanner;

public class TestJdbcCRUD {
	
	
	public static void main(String[] args) {
	
		JdbcCRUD fruits=new JdbcCRUD();
		fruits.save(new Fruits("Apple", 10));
		fruits.save(new Fruits("Watermelon", 20));
		fruits.save(new Fruits("Mango", 50));
		fruits.save(new Fruits("Pineapple", 19));
		fruits.save(new Fruits("Orange", 17));
		
		
		int choice;
		Scanner sc = new Scanner(System.in);
		do
		{
			System.out.println("1. Display");
			System.out.println("2. Delete");
			System.out.println("Enter choice: ");
			choice=sc.nextInt();
			
			switch(choice) {
			case 1:
				List<Fruits> list=fruits.display();
				System.out.println(list);
			break;
			case 2:
				System.out.println("Enter name to delete");
				String name=sc.next();
				fruits.delete(name);
			break;
			
			}
		}while(choice!=3);
		
		
	}
}
