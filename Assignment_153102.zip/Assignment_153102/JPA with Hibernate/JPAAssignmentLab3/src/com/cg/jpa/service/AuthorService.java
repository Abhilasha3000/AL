package com.cg.jpa.service;

import java.util.List;

import com.cg.jpa.entity.Book;

public interface AuthorService {
	public abstract List<Book> getAllBooks();
}
