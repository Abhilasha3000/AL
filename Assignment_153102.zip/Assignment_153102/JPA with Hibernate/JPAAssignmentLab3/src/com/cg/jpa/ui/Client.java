package com.cg.jpa.ui;

import java.util.List;
import java.util.Scanner;

import com.cg.jpa.entity.Book;
import com.cg.jpa.service.AuthorService;
import com.cg.jpa.service.AuthorServiceImpl;

public class Client {
AuthorService service;
public Client()
{
	service=new AuthorServiceImpl();
}
public void menu()
{
	String ans;
	Scanner sc=new Scanner(System.in);
	do {
		System.out.println("1.insert");
		System.out.println("2.update");
		System.out.println("3.delete");
		System.out.println("4.find");
		System.out.println("5.exit");
		System.out.println("Enter your choice");
		int choice=sc.nextInt();
		switch(choice)
		{
		case 1:
			System.out.println("***List All Books***");
			List<Book> list=service.getAllBooks();
			for(Book book:list)
			{
				System.out.println(book);
			}
			break;
		}System.out.println("\nDo you want to continue: Y/N ");
		ans=sc.next();
	}while(ans.equalsIgnoreCase("y"));
	System.out.println("\nThank you for using this service!");	
	
	
}
public static void main(String[] args) {
	Client client=new Client();
	while(true)
		client.menu();
}

}

