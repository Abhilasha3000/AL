package com.cg.jpa.dao;

import java.util.List;

import com.cg.jpa.entity.Book;

public interface AuthorDao {
public abstract List<Book> getAllBooks();
}
