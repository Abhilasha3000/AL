package com.cg.jpa.service;

import java.util.List;

import com.cg.jpa.dao.AuthorDao;
import com.cg.jpa.dao.AuthrDaoImpl;
import com.cg.jpa.entity.Book;

public class AuthorServiceImpl implements AuthorService {
	private AuthorDao dao;

	public AuthorServiceImpl() {
		dao = new AuthrDaoImpl();
	}

	@Override
	public List<Book> getAllBooks() {

		return dao.getAllBooks();
	}

}
