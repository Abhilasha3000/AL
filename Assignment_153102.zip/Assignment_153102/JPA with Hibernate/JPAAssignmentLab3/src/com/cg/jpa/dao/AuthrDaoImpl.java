package com.cg.jpa.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.cg.jpa.entity.Book;
import com.cg.jpa.entity.JPAUtil;

public class AuthrDaoImpl implements AuthorDao {
	private EntityManager entityManager = JPAUtil.getEntityManager();

	@Override
	public List<Book> getAllBooks() {
		String str = "select book from book12 book";
		TypedQuery<Book> query = entityManager.createQuery(str, Book.class);
		List<Book> bookList = query.getResultList();
		return bookList;

	}

}
