package com.cg.jpa.ui;

import java.util.Scanner;

import com.cg.jpa.entity.Author;
import com.cg.jpa.service.AuthorService;
import com.cg.jpa.service.AuthorServiceImpl;

public class Client {
	AuthorService service ;
	String ans;
	public Client (){
		service= new AuthorServiceImpl();
		}
	public void menu()
	{
		
		Scanner sc=new Scanner(System.in);
		do {
			System.out.println("1.insert");
			System.out.println("2.update");
			System.out.println("3.delete");
			System.out.println("4.find");
			System.out.println("5.exit");
			System.out.println("Enter your choice");
			int choice=sc.nextInt();
			switch(choice)
			{
			case 1:
				System.out.println("Enter firstname");
				String fName=sc.next();
				System.out.println("Enter Middle name");
				String mName=sc.next();
				System.out.println("Enter last name");
				String lName=sc.next();
				System.out.println("Enter mobile no");
				String phno=sc.next();
				Author author=new Author(fName,mName,lName,phno);
				service.addAuthor(author);
				System.out.println(author);
				break;
			case 2:
				System.out.println("Enter id");
				int id1=sc.nextInt();
				System.out.println("enter mobile no");
				String pno1=sc.next();
				Author a=service.updateAuthor(id1,pno1);
				System.out.println(a);
				
				break;
			case 3:
				System.out.println("Enter id");
				int id2=sc.nextInt();
				service.removeAuthor(id2);
				System.out.println("Id Deleted");
				break;
			case 4:
				System.out.println("Enter id");
				int id3=sc.nextInt();
				Author a5=service.findAuthorById(id3);
				System.out.println(a5);
				break;
				default:
					System.out.println("Invalid option");
					
			}System.out.println("\nDo you want to continue: Y/N ");
			ans=sc.next();
		}while(ans.equalsIgnoreCase("y"));
		System.out.println("\nThank you for using this service!");	
		
	}
	public static void main(String[] args) {
		Client client=new Client();
		while(true)
			client.menu();
	}
	
}
