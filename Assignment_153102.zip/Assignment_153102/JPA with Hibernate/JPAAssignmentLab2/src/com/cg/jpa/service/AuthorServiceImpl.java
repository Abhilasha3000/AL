package com.cg.jpa.service;

import com.cg.jpa.dao.AuthorDao;
import com.cg.jpa.dao.AuthorDaoImpl;
import com.cg.jpa.entity.Author;



public class AuthorServiceImpl implements AuthorService{

	private AuthorDao dao;

	public AuthorServiceImpl() {
		dao = new AuthorDaoImpl();
	}
	

	@Override
	public Author updateAuthor(int id1,String phno1) {
		dao.beginTransaction();
		Author author1= dao.updateAuthor(id1,phno1);
		dao.commitTransaction();
		return author1;
	}

	@Override
	public void removeAuthor(int id2) {
		dao.beginTransaction();
		dao.removeAuthor(id2);
		dao.commitTransaction();
	}

	@Override
	public Author findAuthorById(int id) {
		
		Author author  = dao.findAuthorById(id);
		return author;
	}


	@Override
	public Author addAuthor(Author author) {
		dao.beginTransaction();
		dao.addAuthor(author);
		dao.commitTransaction();
		return null;
	}


	
	
}
