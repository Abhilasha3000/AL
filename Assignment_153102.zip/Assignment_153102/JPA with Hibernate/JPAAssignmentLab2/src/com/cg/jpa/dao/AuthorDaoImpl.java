package com.cg.jpa.dao;

import javax.persistence.EntityManager;

import com.cg.jpa.entity.Author;
import com.cg.jpa.entity.JPAUtil;

public class AuthorDaoImpl implements AuthorDao {

	private EntityManager entityManager;

	public AuthorDaoImpl() {
		entityManager = JPAUtil.getEntityManager();
	}

	@Override
	public void commitTransaction() {

		entityManager.getTransaction().commit();
	}

	@Override
	public void beginTransaction() {

		entityManager.getTransaction().begin();

	}

	@Override
	public Author updateAuthor(int id1,String phno1) {
		Author author1=findAuthorById(id1);
		author1.setPhoneNo(phno1);
		entityManager.merge(author1);
		return author1;

	}

	@Override
	public void removeAuthor(int id2) {
		Author a2=findAuthorById(id2);
		entityManager.remove(a2);

	}

	@Override
	public Author findAuthorById(int id) {
		Author author = entityManager.find(Author.class, id);
		return author;
	}

	@Override
	public Author addAuthor(Author author) {
		entityManager.persist(author);
		return null;
	}

}
