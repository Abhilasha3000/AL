package com.cg.jpa.dao;

import com.cg.jpa.entity.Author;


public interface AuthorDao {
	public abstract Author addAuthor(Author author);
	public abstract Author updateAuthor(int id1,String phno1);

public abstract void removeAuthor(int id2);

public abstract Author findAuthorById(int id);

public abstract void commitTransaction();

public abstract void beginTransaction();

}
