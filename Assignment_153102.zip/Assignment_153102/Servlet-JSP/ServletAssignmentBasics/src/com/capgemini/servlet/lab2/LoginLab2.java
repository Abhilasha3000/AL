package com.capgemini.servlet.lab2;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class LoginLab2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public LoginLab2() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String un=request.getParameter("input-1");
		String password=request.getParameter("input-2");
		PrintWriter pw=response.getWriter();

		RequestDispatcher rd;
		if(un.equals("admin") && password.equals("admin"))
		{
			System.out.println("Success");
			rd = request.getRequestDispatcher("Success.html");
		}
		else
		{
			System.out.println("Failure");
			rd = request.getRequestDispatcher("Failure.html");
		}
		rd.forward(request, response);
	}
}
