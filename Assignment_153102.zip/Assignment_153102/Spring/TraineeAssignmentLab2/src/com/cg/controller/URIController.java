package com.cg.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.beans.Trainee;

@Controller
public class URIController {

	@RequestMapping("/")
	public String getIndexPage() {
		return "indexPage";
	}
	
	@RequestMapping("/login")
	public String getLoginPage() {
		return "login";
		
	}
	
	@RequestMapping("/addTrainee")
	public String getTrainees() {
		return "addTrainee";
	}
	
	@RequestMapping("/deleteTrainee")
	public String getDeleteTrainee() {
		return "deleteTrainee";
	}
	@RequestMapping("/modifyTrainee")
	public String getModifyTrainee() {
		return "modifyTrainee";
	}
	@RequestMapping("/retrieveTrainee")
	public String getRetrieveTrainee() {
		return "retrieveTrainee";
	}

	@ModelAttribute("trainee")
	public Trainee getTrainee()
	{
		return new Trainee();
	}
	
}
