package com.cg.controller;
import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.beans.Trainee;
import com.cg.exception.TraineeNotFoundException;
import com.cg.exception.TraineeServicesDownException;
import com.cg.service.ITraineeService;
import com.cg.service.TraineeService;

@Controller
public class TraineeController {
	
	@Autowired(required=true)
	private ITraineeService traineeService;
	@RequestMapping(value="/loginPage",method=RequestMethod.POST)
	public ModelAndView loginAdmin(@ModelAttribute("trainee") Trainee trainee)
	{	
		return new ModelAndView("target", "trainee", trainee);
	

	}
	@RequestMapping(value="/addTrainee",method=RequestMethod.POST)
	public ModelAndView addPage(@ModelAttribute("trainee") Trainee trainee)
	{
		try {
			trainee=traineeService.addTrainee(trainee);
			ModelAndView modelAndView = new ModelAndView("addSuccessPage","trainee",trainee);
			return modelAndView;
		} catch (TraineeServicesDownException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return new ModelAndView("errorPage");
	 
	}
	@RequestMapping(value="/deleteTrainee",method=RequestMethod.POST)
	public ModelAndView getDelete(@ModelAttribute("trainee") Trainee trainee) throws TraineeNotFoundException, TraineeServicesDownException {
				trainee=traineeService.deleteTrainee(trainee.getTraineeId());
				ModelAndView modelAndView = new ModelAndView("deleteTraineeInfo","trainee",trainee);
				return modelAndView;
			
		}
	@RequestMapping(value="/modifyTrainee",method=RequestMethod.POST)
	public ModelAndView modifyPage(@ModelAttribute("trainee") Trainee trainee) throws TraineeNotFoundException, TraineeServicesDownException
	{
		trainee=traineeService.getTraineeInfo(trainee.getTraineeId());
		ModelAndView modelAndView = new ModelAndView("update","trainee",trainee);
		return modelAndView;
	
		
	}
	@RequestMapping(value="/update")
	public ModelAndView getUpdateTrainee(@ModelAttribute("trainee") Trainee trainee) throws TraineeNotFoundException, TraineeServicesDownException {
				Trainee trainee1=traineeService.updateTrainee(trainee);
				ModelAndView modelAndView = new ModelAndView("modifyTraineeInfo", "trainee", trainee);
				return modelAndView;
			
		}
	@RequestMapping(value="/retrieve")
	public ModelAndView getInformation(@ModelAttribute("trainee") Trainee trainee) throws TraineeNotFoundException, TraineeServicesDownException {
		trainee=traineeService.getTraineeInfo(trainee.getTraineeId());
		ModelAndView modelAndView = new ModelAndView("retrieveTraineeInfo", "trainee", trainee);
		return modelAndView;
			
		}
	@RequestMapping(value="/retrieveTrainees")
	public ModelAndView getInformations() throws TraineeNotFoundException, TraineeServicesDownException {
		List<Trainee> list=traineeService.getAllTrainees();
		ModelAndView modelAndView = new ModelAndView("retrievetraineesInfo", "trainee", list);
		return modelAndView;
			
		}
}
	