package com.capgemini.bean;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

public class Employee1_4 {

/*List employeeList;
public List getEmployeeList() {
	return employeeList;
}

public void setEmployeeList(List employeeList) {
	this.employeeList = employeeList;
}*/
int employeeId;
String employeeName;
double salary;
int age;
@Autowired
private List employeeList;

public List getEmployeeList() {
	return employeeList;
}

public void setEmployeeList(List employeeList) {
	this.employeeList = employeeList;
}

public Employee1_4(int employeeId, String employeeName, double salary, int age) {
	super();
	this.employeeId = employeeId;
	this.employeeName = employeeName;
	this.salary = salary;
	this.age = age;
}

public Employee1_4() {
	super();
}

@Override
public String toString() {
	return "Employee1_4 [employeeId=" + employeeId + ", employeeName=" + employeeName + ", salary=" + salary + ", age="
			+ age ;
}





}
