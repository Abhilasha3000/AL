package com.capgemini.bean;

public class Employee1_3 {
int employeeId;
String employeeName;
double salary;
int age;
public int getEmployeeId() {
	return employeeId;
}
public void setEmployeeId(int employeeId) {
	this.employeeId = employeeId;
}
public String getEmployeeName() {
	return employeeName;
}
public void setEmployeeName(String employeeName) {
	this.employeeName = employeeName;
}
public double getSalary() {
	return salary;
}
public void setSalary(double salary) {
	this.salary = salary;
}

public int getAge() {
	return age;
}
public void setAge(int age) {
	this.age = age;
}
@Override
public String toString() {
	return "Employee1_3 [employeeId=" + employeeId + ", employeeName=" + employeeName + ", salary=" + salary + ", age="
			+ age + "]";
}



}
