package com.capgemini.bean;

import java.util.List;

public class Employee1_4_4 {
	List employeeList;

	public List getEmployeeList() {
		return employeeList;
	}

	public void setEmployeeList(List employeeList) {
		this.employeeList = employeeList;
	}
}
