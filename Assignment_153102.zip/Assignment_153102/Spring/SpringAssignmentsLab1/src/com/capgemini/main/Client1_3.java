package com.capgemini.main;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemini.bean.Employee1_3;
import com.capgemini.bean.SBU1_3;

public class Client1_3 {
public static void main(String[] args) {
	ApplicationContext  context=new ClassPathXmlApplicationContext("applicationContext1_3.xml");
	SBU1_3 sb=(SBU1_3) context.getBean("sBU1_3");
	System.out.println("SBU Id:"+sb.getSbuId());
	System.out.println("SBU Name:"+sb.getSbuName());
	System.out.println("SBU Head:"+sb.getSbuHead());
	List<Employee1_3> emp=sb.getEmp();
	System.out.println(emp);
}
}
