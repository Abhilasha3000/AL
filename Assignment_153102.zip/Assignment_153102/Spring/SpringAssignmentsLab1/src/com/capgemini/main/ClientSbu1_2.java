package com.capgemini.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemini.bean.Employee1_2;



public class ClientSbu1_2 {
public static void main(String[] args) {
	ApplicationContext context=new ClassPathXmlApplicationContext("applicationContext1_2.xml");
	 
	Employee1_2 emp=(Employee1_2) context.getBean("employee1_2");
	System.out.println("Employee Id:"+emp.getEmployeeId());
	System.out.println("Employee Name:"+emp.getEmployeeName());
	System.out.println("Employee Salary:"+emp.getSalary());
	System.out.println("Employee Age:"+emp.getAge());
	System.out.println("Employee Sbu id:"+emp.getBussinessUnit().getSbuId());
	System.out.println("Employee Sbu Name:"+emp.getBussinessUnit().getSbuName());
	System.out.println("Employee Sbu Head:"+emp.getBussinessUnit().getSbuHead());
}
}
