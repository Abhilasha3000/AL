package com.capgemini.main;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemini.bean.Employee1_4;

public class Client1_4 {
public static void main(String[] args) {
	
	ApplicationContext  context=new ClassPathXmlApplicationContext("applicationContext1_4.xml");
	Employee1_4 list=(Employee1_4) context.getBean("employee1_4");
	List l1=list.getEmployeeList();
	System.out.println(l1);
	
}
}
