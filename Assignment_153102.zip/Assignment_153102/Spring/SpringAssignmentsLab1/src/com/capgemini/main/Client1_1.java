package com.capgemini.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemini.bean.Employee1_1;

public class Client1_1 {
public static void main(String[] args) {
	ApplicationContext context=new ClassPathXmlApplicationContext("applicationContext1_1.xml");
	 
	Employee1_1 emp=(Employee1_1) context.getBean("employee");
	System.out.println("Employee Id:"+emp.getEmployeeId());
	System.out.println("Employee Name:"+emp.getEmployeeName());
	System.out.println("Employee Salary:"+emp.getSalary());
	System.out.println("Employee Business Unit:"+emp.getBussinessUnit());
	System.out.println("Employee Age:"+emp.getAge());
}
}
